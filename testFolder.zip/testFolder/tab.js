const products = [
   { 
     name: 'fried chicken',
     price: '80',
     type: 'meal'
   }, 
   {
     name: 'burger patty',
     price: '40',
     type: 'meal'
   }, 
   {
     name: 'spagheti',
     price: '60',
     type: 'meal'
   }, 
   {
     name: 'palabok',
     price: '70',
     type: 'meal'
   }, 
   {
     name: 'shanghai meal',
     price: '75',
     type: 'meal'
   },
   {
     name: 'juice',
     price: '20',
     type: 'drink'
   }, 
   {
     name: 'ice tea',
     price: '25',
     type: 'drink'
   }, 
   {
     name: 'cola',
     price: '30',
     type: 'drink'
   }, 
   {
     name: 'sprite',
     price: '30',
     type: 'drink'
   }, 
   {
     name: 'pepsi',
     price: '30',
     type: 'drink'
   },
   {
     name: 'ice cream',
     price: '29',
     type: 'dessert'
   }, 
   {
     name: 'choco fudge',
     price: '30',
     type: 'dessert'
   }, 
   {
     name: 'halo-halo',
     price: '39',
     type: 'dessert'
   }, 
   {
     name: 'milk shake',
     price: '29',
     type: 'dessert'
   }, 
   {
     name: 'mango graham',
     price: '25',
     type: 'dessert'
   }
  ];

// Tabs

const tab = document.querySelector('#tab-list');

const tabList = tab.querySelectorAll('a');

tab.addEventListener('click', (e) => {

tabList.forEach(tab => {
tab.classList.remove('active');
e.target.classList.add('active');
});

displaySelectedTab(e.target);
});

function displaySelectedTab(clickedTab){

let classTab =
clickedTab.classList[0];

if(clickedTab.classList.contains(classTab))
  {
   let list = document.querySelector('#charList');
   list.innerHTML="";
   let tab = products.filter(
    function(product){
     return product.type ==
     classTab
    }
   );
   
   tab.forEach((product)=>
  displayItemToList(product));
  }

}

function displayItemToList(product){
   let list = document.querySelector('#charList');
   
   const row = document.createElement('li');

   row.innerHTML = `
   ${product.name}
   `;
   
   list.appendChild(row);
}