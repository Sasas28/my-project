const products = [
   { 
     name: 'fried chicken',
     price: '80',
     type: 'meal'
   }, 
   {
     name: 'burger patty',
     price: '40',
     type: 'meal'
   }, 
   {
     name: 'spagheti',
     price: '60',
     type: 'meal'
   }, 
   {
     name: 'palabok',
     price: '70',
     type: 'meal'
   }, 
   {
     name: 'shanghai meal',
     price: '75',
     type: 'meal'
   },
   {
     name: 'juice',
     price: '20',
     type: 'drink'
   }, 
   {
     name: 'ice tea',
     price: '25',
     type: 'drink'
   }, 
   {
     name: 'cola',
     price: '30',
     type: 'drink'
   }, 
   {
     name: 'sprite',
     price: '30',
     type: 'drink'
   }, 
   {
     name: 'pepsi',
     price: '30',
     type: 'drink'
   },
   {
     name: 'ice cream',
     price: '29',
     type: 'dessert'
   }, 
   {
     name: 'choco fudge',
     price: '30',
     type: 'dessert'
   }, 
   {
     name: 'halo-halo',
     price: '39',
     type: 'dessert'
   }, 
   {
     name: 'milk shake',
     price: '29',
     type: 'dessert'
   }, 
   {
     name: 'mango graham',
     price: '25',
     type: 'dessert'
   }
  ];
  
// search item
const searchBar = document.querySelector("#searchBar");

searchBar.addEventListener("keyup", e => {
const searchString = e.target.value.toLowerCase();
const filteredString = products.filter(character => {
return (character.name.toLowerCase().includes(searchString));
});
test(filteredString);
});

function addProductToList(product)
 {
   let list = document.querySelector('#charList');
   
   const row = document.createElement('li');

row.setAttribute('class', 'flex');
   row.innerHTML = `
   
    <span class="col-3">${product.name}</span><span class="col-3">&#8369;${product.price}</span><span class="col-3"><button >&plus;</button></span>
    
   `;
   
   list.appendChild(row);
 }
 
function test(a){
 document.querySelector('#charList').innerHTML = "";

if (searchBar.value === ""){
document.querySelector('#charList').innerHTML = "";
}else{
a.forEach(x => {
addProductToList(x);
});
} 

}

function displayChar(characters){
const htmlString = characters.map((character) => {
return `
<li>${character.name}</li>
`;
}).join('');

const charList = document.querySelector('#charList');

if (searchBar.value === ""){
charList.innerHTML = "";
}else{
charList.innerHTML = htmlString;
}

}